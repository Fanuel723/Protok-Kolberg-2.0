/**
 * Enhanced Service Worker for Protokół Kolberg 2.0 PWA
 * Implements advanced caching strategies, offline queue, and background sync
 */

const CACHE_NAME = 'protokol-kolberg-v2.0.0';
const STATIC_CACHE = 'static-v2.0.0';
const DYNAMIC_CACHE = 'dynamic-v2.0.0';
const API_CACHE = 'api-v2.0.0';

// Files to cache immediately
const STATIC_FILES = [
    '/',
    '/index.html',
    '/style.css',
    '/app.js',
    '/pwa-enhanced.js',
    '/ui-enhanced.js',
    '/map-enhanced.js',
    '/ui-components.css',
    '/manifest.json',
    '/offline.html',
    'https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;700&family=Open+Sans:wght@300;400;600;700&display=swap',
    'https://fonts.googleapis.com/icon?family=Material+Icons'
];

// API endpoints to cache
const API_ENDPOINTS = [
    '/api/status',
    '/api/health',
    '/api/imwdp/legends',
    '/api/imwdp/locations',
    '/api/mkp2/messages',
    '/api/aspid/manuscripts'
];

// Cache strategies
const CACHE_STRATEGIES = {
    NETWORK_FIRST: 'network-first',
    CACHE_FIRST: 'cache-first',
    STALE_WHILE_REVALIDATE: 'stale-while-revalidate',
    NETWORK_ONLY: 'network-only',
    CACHE_ONLY: 'cache-only'
};

// Install event - cache static files
self.addEventListener('install', (event) => {
    console.log('🔧 Service Worker installing...');
    
    event.waitUntil(
        Promise.all([
            caches.open(STATIC_CACHE).then(cache => {
                console.log('📦 Caching static files...');
                return cache.addAll(STATIC_FILES);
            }),
            caches.open(API_CACHE).then(cache => {
                console.log('🔌 Pre-caching API endpoints...');
                return Promise.allSettled(
                    API_ENDPOINTS.map(url => 
                        fetch(url).then(response => {
                            if (response.ok) {
                                return cache.put(url, response);
                            }
                        }).catch(() => {
                            // Ignore errors for pre-caching
                        })
                    )
                );
            })
        ]).then(() => {
            console.log('✅ Service Worker installed successfully');
            return self.skipWaiting();
        })
    );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
    console.log('🚀 Service Worker activating...');
    
    event.waitUntil(
        Promise.all([
            // Clean up old caches
            caches.keys().then(cacheNames => {
                return Promise.all(
                    cacheNames.map(cacheName => {
                        if (cacheName !== STATIC_CACHE && 
                            cacheName !== DYNAMIC_CACHE && 
                            cacheName !== API_CACHE) {
                            console.log('🗑️ Deleting old cache:', cacheName);
                            return caches.delete(cacheName);
                        }
                    })
                );
            }),
            // Claim all clients
            self.clients.claim()
        ]).then(() => {
            console.log('✅ Service Worker activated successfully');
        })
    );
});

// Fetch event - implement caching strategies
self.addEventListener('fetch', (event) => {
    const { request } = event;
    const url = new URL(request.url);
    
    // Skip non-GET requests for caching
    if (request.method !== 'GET') {
        return;
    }
    
    // Skip chrome-extension and other non-http requests
    if (!url.protocol.startsWith('http')) {
        return;
    }
    
    event.respondWith(handleRequest(request));
});

async function handleRequest(request) {
    const url = new URL(request.url);
    
    try {
        // API requests - Stale While Revalidate
        if (url.pathname.startsWith('/api/')) {
            return await staleWhileRevalidate(request, API_CACHE);
        }
        
        // Static assets - Cache First
        if (isStaticAsset(url.pathname)) {
            return await cacheFirst(request, STATIC_CACHE);
        }
        
        // HTML pages - Network First with offline fallback
        if (request.headers.get('accept')?.includes('text/html')) {
            return await networkFirstWithFallback(request);
        }
        
        // External resources (fonts, etc.) - Cache First
        if (url.origin !== self.location.origin) {
            return await cacheFirst(request, DYNAMIC_CACHE);
        }
        
        // Default - Network First
        return await networkFirst(request, DYNAMIC_CACHE);
        
    } catch (error) {
        console.error('Fetch error:', error);
        return await getOfflineFallback(request);
    }
}

// Cache strategies implementation
async function networkFirst(request, cacheName) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            const cache = await caches.open(cacheName);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        throw error;
    }
}

async function cacheFirst(request, cacheName) {
    const cachedResponse = await caches.match(request);
    
    if (cachedResponse) {
        return cachedResponse;
    }
    
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            const cache = await caches.open(cacheName);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        throw error;
    }
}

async function staleWhileRevalidate(request, cacheName) {
    const cachedResponse = await caches.match(request);
    
    const networkResponsePromise = fetch(request).then(response => {
        if (response.ok) {
            const cache = caches.open(cacheName);
            cache.then(c => c.put(request, response.clone()));
        }
        return response;
    }).catch(() => {
        // Network failed, but we might have cache
    });
    
    return cachedResponse || networkResponsePromise;
}

async function networkFirstWithFallback(request) {
    try {
        const networkResponse = await fetch(request);
        
        if (networkResponse.ok) {
            const cache = await caches.open(DYNAMIC_CACHE);
            cache.put(request, networkResponse.clone());
        }
        
        return networkResponse;
    } catch (error) {
        // Try cache first
        const cachedResponse = await caches.match(request);
        if (cachedResponse) {
            return cachedResponse;
        }
        
        // Return offline page
        return await caches.match('/offline.html') || new Response('Offline', { status: 503 });
    }
}

async function getOfflineFallback(request) {
    if (request.headers.get('accept')?.includes('text/html')) {
        return await caches.match('/offline.html') || new Response('Offline', { status: 503 });
    }
    
    return new Response('Offline', { status: 503 });
}

function isStaticAsset(pathname) {
    const staticExtensions = ['.css', '.js', '.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico', '.woff', '.woff2'];
    return staticExtensions.some(ext => pathname.endsWith(ext));
}

// Background Sync for offline queue
self.addEventListener('sync', (event) => {
    console.log('🔄 Background sync triggered:', event.tag);
    
    if (event.tag === 'offline-queue') {
        event.waitUntil(processOfflineQueue());
    }
});

async function processOfflineQueue() {
    try {
        // Get offline queue from IndexedDB
        const db = await openIndexedDB();
        const transaction = db.transaction(['offlineQueue'], 'readonly');
        const store = transaction.objectStore('offlineQueue');
        const queueItems = await getAllFromStore(store);
        
        console.log(`📤 Processing ${queueItems.length} offline queue items`);
        
        for (const item of queueItems) {
            if (item.status === 'pending') {
                try {
                    await processQueueItem(item);
                    await updateQueueItemStatus(item.id, 'completed');
                    
                    // Notify clients of successful sync
                    self.clients.matchAll().then(clients => {
                        clients.forEach(client => {
                            client.postMessage({
                                type: 'BACKGROUND_SYNC_SUCCESS',
                                payload: {
                                    type: item.type,
                                    message: `${item.type} synchronized successfully`
                                }
                            });
                        });
                    });
                    
                } catch (error) {
                    console.error('Failed to process queue item:', error);
                    await updateQueueItemStatus(item.id, 'failed');
                }
            }
        }
        
    } catch (error) {
        console.error('Background sync error:', error);
    }
}

async function processQueueItem(item) {
    const { type, data } = item;
    
    switch (type) {
        case 'legend':
            return await fetch('/api/imwdp/add-legend', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            
        case 'manuscript':
            const formData = new FormData();
            formData.append('file', data.file);
            return await fetch('/api/aspid/upload', {
                method: 'POST',
                body: formData
            });
            
        case 'message':
            return await fetch('/api/mkp2/send', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            
        default:
            throw new Error(`Unknown queue item type: ${type}`);
    }
}

// IndexedDB helpers
function openIndexedDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('ProtocolKolbergDB', 1);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
}

function getAllFromStore(store) {
    return new Promise((resolve, reject) => {
        const request = store.getAll();
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
}

async function updateQueueItemStatus(id, status) {
    const db = await openIndexedDB();
    const transaction = db.transaction(['offlineQueue'], 'readwrite');
    const store = transaction.objectStore('offlineQueue');
    
    const item = await new Promise((resolve, reject) => {
        const request = store.get(id);
        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);
    });
    
    if (item) {
        item.status = status;
        await new Promise((resolve, reject) => {
            const request = store.put(item);
            request.onerror = () => reject(request.error);
            request.onsuccess = () => resolve(request.result);
        });
    }
}

// Push notifications
self.addEventListener('push', (event) => {
    console.log('📬 Push notification received');
    
    const options = {
        body: event.data ? event.data.text() : 'Nowa legenda została dodana!',
        icon: '/assets/icons/icon-192x192.png',
        badge: '/assets/icons/badge-72x72.png',
        vibrate: [200, 100, 200],
        data: {
            url: '/'
        },
        actions: [
            {
                action: 'open',
                title: 'Otwórz aplikację',
                icon: '/assets/icons/action-open.png'
            },
            {
                action: 'close',
                title: 'Zamknij',
                icon: '/assets/icons/action-close.png'
            }
        ],
        requireInteraction: true,
        silent: false
    };

    event.waitUntil(
        self.registration.showNotification('Protokół Kolberg 2.0', options)
    );
});

// Notification click handler
self.addEventListener('notificationclick', (event) => {
    console.log('🔔 Notification clicked:', event.action);
    
    event.notification.close();
    
    if (event.action === 'open' || !event.action) {
        event.waitUntil(
            clients.matchAll({ type: 'window' }).then(clientList => {
                // Check if app is already open
                for (const client of clientList) {
                    if (client.url === self.location.origin && 'focus' in client) {
                        return client.focus();
                    }
                }
                
                // Open new window
                if (clients.openWindow) {
                    return clients.openWindow('/');
                }
            })
        );
    }
});

// Message handler for communication with main thread
self.addEventListener('message', (event) => {
    console.log('💬 Message received in SW:', event.data);
    
    if (event.data && event.data.type === 'SKIP_WAITING') {
        self.skipWaiting();
    }
    
    if (event.data && event.data.type === 'REGISTER_SYNC') {
        self.registration.sync.register('offline-queue');
    }
});

// Periodic background sync (if supported)
self.addEventListener('periodicsync', (event) => {
    console.log('⏰ Periodic sync triggered:', event.tag);
    
    if (event.tag === 'content-sync') {
        event.waitUntil(syncContent());
    }
});

async function syncContent() {
    try {
        // Sync legends, manuscripts, and other content
        const endpoints = ['/api/imwdp/legends', '/api/aspid/manuscripts'];
        
        for (const endpoint of endpoints) {
            try {
                const response = await fetch(endpoint);
                if (response.ok) {
                    const cache = await caches.open(API_CACHE);
                    await cache.put(endpoint, response);
                }
            } catch (error) {
                console.error(`Failed to sync ${endpoint}:`, error);
            }
        }
        
    } catch (error) {
        console.error('Periodic sync error:', error);
    }
}

// Error handler
self.addEventListener('error', (event) => {
    console.error('❌ Service Worker error:', event.error);
});

self.addEventListener('unhandledrejection', (event) => {
    console.error('❌ Unhandled promise rejection in SW:', event.reason);
});

console.log('🏰 Protokół Kolberg 2.0 Service Worker loaded');

