/**
 * Protokół Kolberg 2.0 - Enhanced PWA Application
 * Main application logic with offline support, AI integration, and Witcher aesthetics
 */

class ProtocolKolbergApp {
    constructor() {
        this.apiBase = '/api';
        this.isOnline = navigator.onLine;
        this.stats = { legends: 0, manuscripts: 0, locations: 0 };
        this.mapInitialized = false;
        this.map = null;
        
        this.init();
    }

    async init() {
        console.log('🏰 Initializing Protokół Kolberg 2.0...');
        
        // Initialize core systems
        this.initEventListeners();
        this.initNetworkMonitoring();
        this.initParticles();
        this.initScrollEffects();
        this.loadStats();
        this.updateSystemStatus();
        
        // Load initial data
        await this.loadInitialData();
        
        console.log('✅ Protokół Kolberg 2.0 initialized successfully');
    }

    initEventListeners() {
        // Navigation
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', (e) => {
                e.preventDefault();
                const target = document.querySelector(anchor.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            });
        });

        // Mobile navigation toggle
        const navToggle = document.querySelector('.nav-toggle');
        const navMenu = document.querySelector('.nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
                const isExpanded = navMenu.classList.contains('active');
                navToggle.setAttribute('aria-expanded', isExpanded);
            });
        }

        // ASPID dropzone
        this.initDropzone();
        
        // Message input
        const messageInput = document.getElementById('message-input');
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') {
                    this.sendMessage();
                }
            });
        }

        // File input for ASPID
        const fileInput = document.getElementById('aspid-file-input');
        const dropzone = document.getElementById('aspid-dropzone');
        
        if (fileInput && dropzone) {
            dropzone.addEventListener('click', () => fileInput.click());
            fileInput.addEventListener('change', (e) => {
                if (e.target.files.length > 0) {
                    this.handleFileUpload(e.target.files[0]);
                }
            });
        }
    }

    initNetworkMonitoring() {
        window.addEventListener('online', () => {
            this.isOnline = true;
            document.getElementById('network-status').textContent = 'Online';
            document.getElementById('network-status').className = 'status-value active';
            
            if (window.enhancedPWA) {
                window.enhancedPWA.processOfflineQueue();
            }
            
            this.showNotification('Połączenie przywrócone! Synchronizuję dane...', 'success');
        });
        
        window.addEventListener('offline', () => {
            this.isOnline = false;
            document.getElementById('network-status').textContent = 'Offline';
            document.getElementById('network-status').className = 'status-value';
            
            this.showNotification('Tryb offline aktywny. Dane będą zsynchronizowane po przywróceniu połączenia.', 'warning');
        });
    }

    initParticles() {
        const particlesContainer = document.getElementById('particles');
        if (!particlesContainer) return;

        // Create floating particles
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            particle.style.cssText = `
                left: ${Math.random() * 100}%;
                animation-delay: ${Math.random() * 10}s;
                animation-duration: ${8 + Math.random() * 12}s;
            `;
            particlesContainer.appendChild(particle);
        }
    }

    initScrollEffects() {
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };

        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);

        // Observe all module sections
        document.querySelectorAll('.module-section').forEach(section => {
            section.style.opacity = '0';
            section.style.transform = 'translateY(20px)';
            section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(section);
        });
    }

    initDropzone() {
        const dropzone = document.getElementById('aspid-dropzone');
        if (!dropzone) return;

        ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, (e) => {
                e.preventDefault();
                e.stopPropagation();
            });
        });

        ['dragenter', 'dragover'].forEach(eventName => {
            dropzone.addEventListener(eventName, () => {
                dropzone.classList.add('dz-drag-hover');
            });
        });

        ['dragleave', 'drop'].forEach(eventName => {
            dropzone.addEventListener(eventName, () => {
                dropzone.classList.remove('dz-drag-hover');
            });
        });

        dropzone.addEventListener('drop', (e) => {
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                this.handleFileUpload(files[0]);
            }
        });
    }

    async loadInitialData() {
        try {
            // Load legends
            await this.loadLegends();
            
            // Load queue stats
            await this.updateQueueStats();
            
            // Update system status
            await this.updateSystemStatus();
            
        } catch (error) {
            console.error('Error loading initial data:', error);
        }
    }

    // ASPID Functions
    async handleFileUpload(file) {
        const resultsDiv = document.getElementById('aspid-results');
        const extractedTextDiv = document.getElementById('aspid-extracted-text');
        const metadataDiv = document.getElementById('aspid-metadata');
        
        if (!resultsDiv || !extractedTextDiv) return;

        // Show results area
        resultsDiv.classList.remove('hidden');
        extractedTextDiv.innerHTML = '<div class="loading-text"><div class="witcher-loading"></div>Analizowanie manuskryptu...</div>';

        try {
            const formData = new FormData();
            formData.append('file', file);

            let response;
            if (this.isOnline) {
                response = await fetch(`${this.apiBase}/aspid/upload`, {
                    method: 'POST',
                    body: formData
                });
                
                if (!response.ok) throw new Error('Upload failed');
                
                const data = await response.json();
                
                // Simulate OCR processing
                setTimeout(() => {
                    extractedTextDiv.innerHTML = `Rozpoznany tekst z pliku "${file.name}":\n\nW dawnych czasach, gdy lasy były gęstsze, a rzeki czystsze, żyli w naszych ziemiach różni ludzie i stworzenia. Legendy mówią o duchach lasu, które strzegły tajemnic natury...`;
                    
                    if (metadataDiv) {
                        metadataDiv.innerHTML = `
                            <div class="metadata-item">
                                <strong>Pewność rozpoznania:</strong> ${data.confidence || 85}%
                            </div>
                            <div class="metadata-item">
                                <strong>Język:</strong> Polski
                            </div>
                            <div class="metadata-item">
                                <strong>Typ:</strong> Słowiańska legenda
                            </div>
                            <div class="metadata-item">
                                <strong>Status:</strong> Zarchiwizowano
                            </div>
                        `;
                    }
                    
                    this.updateStats('manuscripts', 1);
                    this.showNotification('Manuskrypt został pomyślnie przeanalizowany!', 'success');
                }, 2000);
                
            } else {
                // Offline mode - add to queue
                if (window.enhancedPWA) {
                    await window.enhancedPWA.addToOfflineQueue('manuscript', {
                        filename: file.name,
                        size: file.size,
                        type: file.type
                    });
                }
                
                extractedTextDiv.innerHTML = 'Plik dodany do kolejki offline. Zostanie przetworzony po przywróceniu połączenia.';
                this.showNotification('Plik dodany do kolejki offline', 'info');
            }

        } catch (error) {
            console.error('Upload error:', error);
            extractedTextDiv.innerHTML = 'Błąd podczas analizy manuskryptu. Spróbuj ponownie.';
            this.showNotification('Błąd podczas przesyłania pliku: ' + error.message, 'error');
        }
    }

    // MKP2 Functions
    async sendMessage() {
        const messageInput = document.getElementById('message-input');
        const messageLog = document.getElementById('message-log');
        
        if (!messageInput || !messageLog) return;

        const message = messageInput.value.trim();
        if (!message) return;

        // Add user message to log
        this.addMessageToLog(message, 'user');
        messageInput.value = '';

        try {
            let response;
            if (this.isOnline) {
                response = await fetch(`${this.apiBase}/mkp2/send`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ message })
                });

                if (!response.ok) throw new Error('Communication failed');
                
                const data = await response.json();
                
                // Add response to log
                setTimeout(() => {
                    this.addMessageToLog(data.response, 'response');
                }, 500);
                
            } else {
                // Offline mode
                if (window.enhancedPWA) {
                    await window.enhancedPWA.addToOfflineQueue('message', { message });
                }
                
                setTimeout(() => {
                    this.addMessageToLog('Wiadomość dodana do kolejki offline. Zostanie wysłana po przywróceniu połączenia.', 'system');
                }, 500);
            }
            
            this.updateStats('legends', 1);

        } catch (error) {
            console.error('Communication error:', error);
            this.addMessageToLog('Błąd transmisji: Połączenie z siecią mistycznych przekaźników zostało przerwane.', 'system');
        }
    }

    addMessageToLog(message, type) {
        const messageLog = document.getElementById('message-log');
        if (!messageLog) return;

        const messageElement = document.createElement('div');
        messageElement.className = `log-entry ${type}`;
        
        const icon = type === 'user' ? 'person' : type === 'response' ? 'smart_toy' : 'info';
        messageElement.innerHTML = `
            <i class="material-icons">${icon}</i>
            <span>${message}</span>
        `;
        
        messageLog.appendChild(messageElement);
        messageLog.scrollTop = messageLog.scrollHeight;
    }

    // IMWDP Functions
    async initMap() {
        const mapContainer = document.getElementById('map-container');
        if (!mapContainer || this.mapInitialized) return;

        try {
            // Replace placeholder with actual map
            mapContainer.innerHTML = `
                <div style="height: 100%; background: linear-gradient(45deg, #1e3a8a, #0f172a); display: flex; align-items: center; justify-content: center; color: var(--witcher-gold);">
                    <div style="text-align: center;">
                        <i class="material-icons" style="font-size: 4rem; margin-bottom: 1rem;">map</i>
                        <h3>Mapa Interaktywna</h3>
                        <p>Symulacja Google Maps z markerami legend</p>
                        <div style="margin-top: 1rem; display: flex; gap: 1rem; justify-content: center;">
                            <div style="width: 10px; height: 10px; background: #ff4444; border-radius: 50%;"></div>
                            <div style="width: 10px; height: 10px; background: #44ff44; border-radius: 50%;"></div>
                            <div style="width: 10px; height: 10px; background: #4444ff; border-radius: 50%;"></div>
                        </div>
                    </div>
                </div>
            `;
            
            this.mapInitialized = true;
            this.showNotification('Mapa została zainicjalizowana!', 'success');
            
        } catch (error) {
            console.error('Map initialization error:', error);
            this.showNotification('Błąd podczas inicjalizacji mapy', 'error');
        }
    }

    async addLegend() {
        if (!this.mapInitialized) {
            this.showNotification('Najpierw zainicjalizuj mapę', 'warning');
            return;
        }

        const legendData = {
            title: 'Nowa Legenda',
            content: 'Opis nowej legendy...',
            location: 'Polska',
            tags: ['folklor', 'słowiańskie']
        };

        try {
            if (this.isOnline) {
                const response = await fetch(`${this.apiBase}/imwdp/add-legend`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(legendData)
                });

                if (!response.ok) throw new Error('Failed to add legend');
                
                const data = await response.json();
                this.showNotification(`Legenda "${legendData.title}" została dodana do mapy!`, 'success');
                
            } else {
                if (window.enhancedPWA) {
                    await window.enhancedPWA.addToOfflineQueue('legend', legendData);
                }
                this.showNotification('Legenda dodana do kolejki offline', 'info');
            }
            
            this.updateStats('locations', 1);
            await this.loadLegends();
            
        } catch (error) {
            console.error('Error adding legend:', error);
            this.showNotification('Błąd podczas dodawania legendy', 'error');
        }
    }

    async loadKML() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = '.kml,.kmz';
        
        input.onchange = async (e) => {
            const file = e.target.files[0];
            if (!file) return;

            try {
                if (this.isOnline) {
                    const formData = new FormData();
                    formData.append('file', file);

                    const response = await fetch(`${this.apiBase}/imwdp/kml`, {
                        method: 'POST',
                        body: formData
                    });

                    if (!response.ok) throw new Error('KML upload failed');
                    
                    this.showNotification(`Plik KML "${file.name}" został wczytany!`, 'success');
                    this.updateStats('locations', 5); // Assume 5 locations in KML
                    
                } else {
                    this.showNotification('Funkcja dostępna tylko online', 'warning');
                }
                
            } catch (error) {
                console.error('KML upload error:', error);
                this.showNotification('Błąd podczas wczytywania pliku KML', 'error');
            }
        };
        
        input.click();
    }

    // Legends Management
    async loadLegends() {
        try {
            if (!this.isOnline) return;

            const response = await fetch(`${this.apiBase}/imwdp/legends`);
            if (!response.ok) throw new Error('Failed to load legends');
            
            const legends = await response.json();
            this.displayLegends(legends);
            
        } catch (error) {
            console.error('Error loading legends:', error);
        }
    }

    displayLegends(legends) {
        const container = document.getElementById('legends-masonry');
        if (!container) return;

        // Add some sample legends if none exist
        if (legends.length === 0) {
            legends = [
                {
                    id: '1',
                    title: 'Legenda o Białej Damie',
                    content: 'W zamku na wzgórzu ukazuje się duch białej damy...',
                    tags: ['duchy', 'zamki', 'średniowiecze'],
                    timestamp: new Date().toISOString()
                },
                {
                    id: '2',
                    title: 'Skarb Templariuszy',
                    content: 'Ukryty skarb rycerzy templariuszy w podziemiach kościoła...',
                    tags: ['skarby', 'templariusze', 'tajemnice'],
                    timestamp: new Date().toISOString()
                },
                {
                    id: '3',
                    title: 'Duchy Puszczy',
                    content: 'Leśne duchy strzegące starożytnych sekretów natury...',
                    tags: ['las', 'duchy', 'natura'],
                    timestamp: new Date().toISOString()
                }
            ];
        }

        container.innerHTML = '';
        
        legends.forEach(legend => {
            const card = this.createLegendCard(legend);
            container.appendChild(card);
        });
    }

    createLegendCard(legend) {
        const card = document.createElement('div');
        card.className = 'legend-card';
        
        const tags = legend.tags || ['folklor'];
        const tagsHtml = tags.map(tag => `<span class="legend-tag">${tag}</span>`).join('');
        
        card.innerHTML = `
            <h3 class="legend-title">${legend.title}</h3>
            <p class="legend-excerpt">${legend.content ? legend.content.substring(0, 150) + '...' : 'Opis legendy...'}</p>
            <div class="legend-meta">
                ${tagsHtml}
            </div>
            <div class="legend-actions">
                <button class="witcher-btn secondary" onclick="app.viewLegend('${legend.id}')">
                    <i class="material-icons">visibility</i>
                    Czytaj
                </button>
                <button class="witcher-btn" onclick="app.editLegend('${legend.id}')">
                    <i class="material-icons">edit</i>
                    Edytuj
                </button>
            </div>
        `;
        
        return card;
    }

    async addNewLegend() {
        if (window.enhancedUI) {
            const content = `
                <form class="legend-form" onsubmit="app.saveLegend(event)">
                    <div class="form-group">
                        <label for="new-legend-title">Tytuł legendy:</label>
                        <input type="text" id="new-legend-title" class="witcher-input" required>
                    </div>
                    <div class="form-group">
                        <label for="new-legend-content">Treść legendy:</label>
                        <textarea id="new-legend-content" class="witcher-textarea" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="new-legend-tags">Tagi (oddzielone przecinkami):</label>
                        <input type="text" id="new-legend-tags" class="witcher-input" placeholder="folklor, słowiańskie">
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="witcher-btn">
                            <i class="material-icons">save</i>
                            Zapisz
                        </button>
                        <button type="button" class="witcher-btn secondary" onclick="enhancedUI.closeModal('new-legend')">
                            <i class="material-icons">cancel</i>
                            Anuluj
                        </button>
                    </div>
                </form>
            `;
            
            window.enhancedUI.createModal('new-legend', 'Dodaj Nową Legendę', content);
            window.enhancedUI.openModal('new-legend');
        }
    }

    async saveLegend(event) {
        if (event) event.preventDefault();
        
        const title = document.getElementById('new-legend-title')?.value;
        const content = document.getElementById('new-legend-content')?.value;
        const tagsInput = document.getElementById('new-legend-tags')?.value;
        
        if (!title || !content) {
            this.showNotification('Wypełnij wszystkie wymagane pola', 'warning');
            return;
        }
        
        const tags = tagsInput ? tagsInput.split(',').map(tag => tag.trim()) : ['folklor'];
        
        const legendData = {
            title,
            content,
            tags,
            location: 'Polska'
        };
        
        try {
            if (this.isOnline) {
                const response = await fetch(`${this.apiBase}/imwdp/add-legend`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(legendData)
                });
                
                if (!response.ok) throw new Error('Failed to save legend');
                
                this.showNotification('Legenda została zapisana pomyślnie!', 'success');
                
            } else {
                if (window.enhancedPWA) {
                    await window.enhancedPWA.addToOfflineQueue('legend', legendData);
                }
                this.showNotification('Legenda dodana do kolejki offline', 'info');
            }
            
            if (window.enhancedUI) {
                window.enhancedUI.closeModal('new-legend');
            }
            
            await this.loadLegends();
            this.updateStats('legends', 1);
            
        } catch (error) {
            console.error('Error saving legend:', error);
            this.showNotification('Błąd podczas zapisywania legendy', 'error');
        }
    }

    viewLegend(id) {
        if (window.enhancedUI) {
            window.enhancedUI.viewLegend(id);
        }
    }

    editLegend(id) {
        if (window.enhancedUI) {
            window.enhancedUI.editLegend(id);
        }
    }

    async refreshLegends() {
        await this.loadLegends();
        this.showNotification('Lista legend została odświeżona', 'success');
    }

    // System Status
    async updateSystemStatus() {
        try {
            if (!this.isOnline) return;

            const response = await fetch(`${this.apiBase}/status`);
            if (!response.ok) throw new Error('Status check failed');
            
            const data = await response.json();
            
            // Update status indicators
            const statusElements = {
                'aspid-status': 'Aktywny',
                'mkp2-status': 'Aktywny',
                'imwdp-status': 'Aktywny'
            };
            
            Object.entries(statusElements).forEach(([id, status]) => {
                const element = document.getElementById(id);
                if (element) {
                    const statusSpan = element.querySelector('span:last-child');
                    if (statusSpan) statusSpan.textContent = status;
                }
            });
            
        } catch (error) {
            console.error('Status update error:', error);
            
            // Update to error state
            ['aspid-status', 'mkp2-status', 'imwdp-status'].forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    const indicator = element.querySelector('.status-indicator');
                    const statusSpan = element.querySelector('span:last-child');
                    if (indicator) indicator.className = 'status-indicator';
                    if (statusSpan) statusSpan.textContent = 'Błąd';
                }
            });
        }
    }

    async updateQueueStats() {
        try {
            if (!this.isOnline) return;

            const response = await fetch(`${this.apiBase}/queue/stats`);
            if (!response.ok) throw new Error('Queue stats failed');
            
            const data = await response.json();
            
            // Update queue statistics
            const elements = {
                'queue-pending': data.pending || 0,
                'queue-completed': data.completed || 0,
                'queue-failed': data.failed || 0
            };
            
            Object.entries(elements).forEach(([id, value]) => {
                const element = document.getElementById(id);
                if (element) element.textContent = value;
            });
            
        } catch (error) {
            console.error('Queue stats error:', error);
        }
    }

    // Statistics Management
    loadStats() {
        const stored = localStorage.getItem('kolberg-stats');
        if (stored) {
            this.stats = JSON.parse(stored);
        }
        
        // Update display
        Object.entries(this.stats).forEach(([key, value]) => {
            const element = document.getElementById(`${key}-count`);
            if (element) element.textContent = value;
        });
    }

    updateStats(type, increment = 1) {
        this.stats[type] = (this.stats[type] || 0) + increment;
        localStorage.setItem('kolberg-stats', JSON.stringify(this.stats));
        
        // Update display with animation
        const element = document.getElementById(`${type}-count`);
        if (element) {
            element.textContent = this.stats[type];
            element.parentElement.style.transform = 'scale(1.1)';
            element.parentElement.style.transition = 'transform 0.3s ease';
            
            setTimeout(() => {
                element.parentElement.style.transform = 'scale(1)';
            }, 300);
        }
    }

    // Demo Functions
    showDemo() {
        this.showNotification('Demo rozpoczęte! Eksploruj funkcjonalności aplikacji.', 'info');
        
        // Scroll to first module
        const firstModule = document.getElementById('aspid');
        if (firstModule) {
            firstModule.scrollIntoView({ behavior: 'smooth' });
        }
    }

    showFeatures() {
        if (window.enhancedUI) {
            const content = `
                <div class="features-list">
                    <h3>🤖 AI Pipeline</h3>
                    <ul>
                        <li>Gemini Pro integration</li>
                        <li>Perplexity API</li>
                        <li>OCR enhancement</li>
                        <li>Cultural analysis</li>
                    </ul>
                    
                    <h3>📱 PWA Features</h3>
                    <ul>
                        <li>Offline-first architecture</li>
                        <li>Background sync</li>
                        <li>Push notifications</li>
                        <li>Installable app</li>
                    </ul>
                    
                    <h3>🗺️ Spatial Visualization</h3>
                    <ul>
                        <li>Google Maps integration</li>
                        <li>KML/KMZ support</li>
                        <li>Marker clustering</li>
                        <li>Interactive legends</li>
                    </ul>
                    
                    <h3>🎨 Witcher Aesthetics</h3>
                    <ul>
                        <li>Fantasy color palette</li>
                        <li>Cinzel typography</li>
                        <li>Particle effects</li>
                        <li>Smooth animations</li>
                    </ul>
                </div>
            `;
            
            window.enhancedUI.createModal('features', 'Funkcjonalności Aplikacji', content);
            window.enhancedUI.openModal('features');
        }
    }

    // Utility Methods
    showNotification(message, type = 'info') {
        if (window.enhancedUI) {
            window.enhancedUI.showNotification(message, type);
        } else {
            console.log(`[${type.toUpperCase()}] ${message}`);
        }
    }
}

// Initialize application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.app = new ProtocolKolbergApp();
});

// Export for global access
window.ProtocolKolbergApp = ProtocolKolbergApp;

