/**
 * Enhanced Map Module for Protokół Kolberg 2.0
 * Implements Google Maps with clustering, KML support, and interactive legends
 */

class EnhancedMap {
    constructor() {
        this.map = null;
        this.markers = [];
        this.clusters = null;
        this.infoWindow = null;
        this.kmlLayers = [];
        this.legendData = [];
        this.currentLocation = null;
        
        // Default coordinates for Carpathian region
        this.defaultCenter = { lat: 50.92120553783207, lng: 22.846121600000018 };
        
        this.init();
    }

    async init() {
        await this.loadGoogleMapsAPI();
        this.initMap();
        this.initGeolocation();
        this.initMapControls();
        this.initKMLSupport();
        this.loadSampleLegends();
    }

    // Load Google Maps API dynamically
    async loadGoogleMapsAPI() {
        return new Promise((resolve, reject) => {
            if (window.google && window.google.maps) {
                resolve();
                return;
            }

            const script = document.createElement('script');
            script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&libraries=geometry,places&callback=initGoogleMaps`;
            script.async = true;
            script.defer = true;
            
            window.initGoogleMaps = () => {
                delete window.initGoogleMaps;
                resolve();
            };
            
            script.onerror = () => reject(new Error('Failed to load Google Maps API'));
            document.head.appendChild(script);
        });
    }

    // Initialize the map
    initMap() {
        const mapContainer = document.getElementById('map-container');
        if (!mapContainer) {
            console.error('Map container not found');
            return;
        }

        this.map = new google.maps.Map(mapContainer, {
            center: this.defaultCenter,
            zoom: 10,
            mapTypeId: google.maps.MapTypeId.TERRAIN,
            styles: this.getWitcherMapStyles(),
            mapTypeControl: true,
            streetViewControl: false,
            fullscreenControl: true,
            zoomControl: true,
            gestureHandling: 'cooperative'
        });

        this.infoWindow = new google.maps.InfoWindow({
            maxWidth: 300
        });

        // Initialize marker clustering
        this.initMarkerClustering();
        
        // Add map event listeners
        this.addMapEventListeners();
    }

    // Witcher-themed map styles
    getWitcherMapStyles() {
        return [
            {
                "featureType": "all",
                "elementType": "all",
                "stylers": [
                    { "saturation": -20 },
                    { "lightness": -10 }
                ]
            },
            {
                "featureType": "water",
                "elementType": "all",
                "stylers": [
                    { "color": "#1e3a8a" },
                    { "lightness": -20 }
                ]
            },
            {
                "featureType": "landscape",
                "elementType": "all",
                "stylers": [
                    { "color": "#2d2d2d" },
                    { "lightness": -10 }
                ]
            },
            {
                "featureType": "road",
                "elementType": "all",
                "stylers": [
                    { "color": "#8B4513" },
                    { "lightness": -20 }
                ]
            },
            {
                "featureType": "poi",
                "elementType": "all",
                "stylers": [
                    { "color": "#4c1d95" },
                    { "lightness": -10 }
                ]
            }
        ];
    }

    // Initialize marker clustering
    initMarkerClustering() {
        // Simple clustering implementation (in production, use MarkerClusterer library)
        this.clusters = {
            markers: [],
            clusterMarkers: [],
            
            addMarker: (marker) => {
                this.clusters.markers.push(marker);
                this.updateClusters();
            },
            
            updateClusters: () => {
                // Clear existing cluster markers
                this.clusters.clusterMarkers.forEach(cluster => cluster.setMap(null));
                this.clusters.clusterMarkers = [];
                
                // Simple distance-based clustering
                const clustered = [];
                const unclustered = [...this.clusters.markers];
                
                while (unclustered.length > 0) {
                    const marker = unclustered.shift();
                    const cluster = [marker];
                    
                    for (let i = unclustered.length - 1; i >= 0; i--) {
                        const distance = this.calculateDistance(
                            marker.getPosition(),
                            unclustered[i].getPosition()
                        );
                        
                        if (distance < 5000) { // 5km clustering radius
                            cluster.push(unclustered.splice(i, 1)[0]);
                        }
                    }
                    
                    if (cluster.length > 1) {
                        this.createClusterMarker(cluster);
                    } else {
                        marker.setMap(this.map);
                    }
                }
            }
        };
    }

    // Calculate distance between two points
    calculateDistance(pos1, pos2) {
        const R = 6371000; // Earth's radius in meters
        const dLat = (pos2.lat() - pos1.lat()) * Math.PI / 180;
        const dLng = (pos2.lng() - pos1.lng()) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(pos1.lat() * Math.PI / 180) * Math.cos(pos2.lat() * Math.PI / 180) *
                  Math.sin(dLng/2) * Math.sin(dLng/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    // Create cluster marker
    createClusterMarker(markers) {
        const bounds = new google.maps.LatLngBounds();
        markers.forEach(marker => bounds.extend(marker.getPosition()));
        
        const clusterMarker = new google.maps.Marker({
            position: bounds.getCenter(),
            map: this.map,
            icon: {
                url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                    <svg width="40" height="40" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="20" cy="20" r="18" fill="#8B4513" stroke="#d7cbac" stroke-width="2"/>
                        <text x="20" y="26" text-anchor="middle" fill="#d7cbac" font-family="Arial" font-size="12" font-weight="bold">${markers.length}</text>
                    </svg>
                `),
                scaledSize: new google.maps.Size(40, 40)
            }
        });
        
        clusterMarker.addListener('click', () => {
            this.map.fitBounds(bounds);
            this.map.setZoom(Math.min(this.map.getZoom() + 2, 15));
        });
        
        this.clusters.clusterMarkers.push(clusterMarker);
        
        // Hide individual markers
        markers.forEach(marker => marker.setMap(null));
    }

    // Add map event listeners
    addMapEventListeners() {
        // Right-click to add legend
        this.map.addListener('rightclick', (event) => {
            this.showAddLegendDialog(event.latLng);
        });
        
        // Zoom change listener for clustering
        this.map.addListener('zoom_changed', () => {
            if (this.clusters) {
                this.clusters.updateClusters();
            }
        });
    }

    // Geolocation support
    initGeolocation() {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    this.currentLocation = {
                        lat: position.coords.latitude,
                        lng: position.coords.longitude
                    };
                    
                    // Add current location marker
                    this.addCurrentLocationMarker();
                },
                (error) => {
                    console.log('Geolocation error:', error);
                    this.showNotification('Nie można określić lokalizacji', 'warning');
                }
            );
        }
    }

    addCurrentLocationMarker() {
        if (!this.currentLocation) return;
        
        const marker = new google.maps.Marker({
            position: this.currentLocation,
            map: this.map,
            title: 'Twoja lokalizacja',
            icon: {
                url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                    <svg width="24" height="24" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                        <circle cx="12" cy="12" r="8" fill="#4285f4" stroke="#ffffff" stroke-width="2"/>
                        <circle cx="12" cy="12" r="3" fill="#ffffff"/>
                    </svg>
                `),
                scaledSize: new google.maps.Size(24, 24)
            }
        });
        
        // Center map on current location
        this.map.setCenter(this.currentLocation);
        this.map.setZoom(12);
    }

    // Map controls
    initMapControls() {
        // Custom control for legend toggle
        const legendControl = document.createElement('div');
        legendControl.className = 'map-control';
        legendControl.innerHTML = `
            <button class="witcher-btn" onclick="enhancedMap.toggleLegendPanel()">
                <i class="material-icons">layers</i>
                Legendy
            </button>
        `;
        
        this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(legendControl);
        
        // Custom control for KML upload
        const kmlControl = document.createElement('div');
        kmlControl.className = 'map-control';
        kmlControl.innerHTML = `
            <button class="witcher-btn" onclick="enhancedMap.showKMLUploadDialog()">
                <i class="material-icons">upload_file</i>
                KML
            </button>
        `;
        
        this.map.controls[google.maps.ControlPosition.TOP_RIGHT].push(kmlControl);
    }

    // KML Support
    initKMLSupport() {
        // Initialize KML layer support
        this.kmlLayers = [];
    }

    loadKMLFile(file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            try {
                const kmlData = e.target.result;
                this.parseAndDisplayKML(kmlData, file.name);
                this.showNotification(`Plik KML ${file.name} został załadowany pomyślnie!`, 'success');
            } catch (error) {
                console.error('KML parsing error:', error);
                this.showNotification('Błąd podczas ładowania pliku KML', 'error');
            }
        };
        reader.readAsText(file);
    }

    parseAndDisplayKML(kmlData, filename) {
        // Simple KML parsing (in production, use proper KML parser)
        const parser = new DOMParser();
        const kmlDoc = parser.parseFromString(kmlData, 'text/xml');
        
        const placemarks = kmlDoc.getElementsByTagName('Placemark');
        const bounds = new google.maps.LatLngBounds();
        
        Array.from(placemarks).forEach((placemark, index) => {
            const name = placemark.getElementsByTagName('name')[0]?.textContent || `Punkt ${index + 1}`;
            const description = placemark.getElementsByTagName('description')[0]?.textContent || '';
            const coordinates = placemark.getElementsByTagName('coordinates')[0]?.textContent;
            
            if (coordinates) {
                const coords = coordinates.trim().split(',');
                const lat = parseFloat(coords[1]);
                const lng = parseFloat(coords[0]);
                
                if (!isNaN(lat) && !isNaN(lng)) {
                    const position = { lat, lng };
                    bounds.extend(position);
                    
                    this.addLegendMarker({
                        position,
                        title: name,
                        description,
                        source: filename,
                        type: 'kml'
                    });
                }
            }
        });
        
        if (!bounds.isEmpty()) {
            this.map.fitBounds(bounds);
        }
    }

    // Legend management
    addLegendMarker(legendData) {
        const marker = new google.maps.Marker({
            position: legendData.position,
            map: this.map,
            title: legendData.title,
            icon: this.getLegendIcon(legendData.type)
        });
        
        marker.addListener('click', () => {
            this.showLegendInfo(legendData, marker);
        });
        
        this.markers.push(marker);
        this.legendData.push(legendData);
        
        if (this.clusters) {
            this.clusters.addMarker(marker);
        }
        
        return marker;
    }

    getLegendIcon(type) {
        const icons = {
            legend: '#d7cbac',
            kml: '#8B4513',
            user: '#4285f4',
            historical: '#8b0000'
        };
        
        const color = icons[type] || icons.legend;
        
        return {
            url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg width="32" height="32" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg">
                    <path d="M16 2 L16 2 C20.4 2 24 5.6 24 10 C24 16 16 30 16 30 S8 16 8 10 C8 5.6 11.6 2 16 2 Z" fill="${color}" stroke="#000" stroke-width="1"/>
                    <circle cx="16" cy="10" r="4" fill="#000"/>
                </svg>
            `),
            scaledSize: new google.maps.Size(32, 32),
            anchor: new google.maps.Point(16, 30)
        };
    }

    showLegendInfo(legendData, marker) {
        const content = `
            <div class="legend-info-window">
                <h3 class="legend-title">${legendData.title}</h3>
                <p class="legend-description">${legendData.description}</p>
                <div class="legend-meta">
                    <span class="legend-type">${legendData.type}</span>
                    ${legendData.source ? `<span class="legend-source">Źródło: ${legendData.source}</span>` : ''}
                </div>
                <div class="legend-actions">
                    <button class="witcher-btn secondary" onclick="enhancedMap.editLegend('${legendData.id}')">
                        <i class="material-icons">edit</i>
                        Edytuj
                    </button>
                    <button class="witcher-btn" onclick="enhancedMap.shareLegend('${legendData.id}')">
                        <i class="material-icons">share</i>
                        Udostępnij
                    </button>
                </div>
            </div>
        `;
        
        this.infoWindow.setContent(content);
        this.infoWindow.open(this.map, marker);
    }

    // Dialog methods
    showAddLegendDialog(latLng) {
        const content = `
            <form class="add-legend-form">
                <div class="form-group">
                    <label for="legend-title">Tytuł legendy:</label>
                    <input type="text" id="legend-title" class="witcher-input" placeholder="Wprowadź tytuł legendy">
                </div>
                <div class="form-group">
                    <label for="legend-description">Opis legendy:</label>
                    <textarea id="legend-description" class="witcher-textarea" placeholder="Opisz legendę..."></textarea>
                </div>
                <div class="form-group">
                    <label for="legend-type">Typ legendy:</label>
                    <select id="legend-type" class="witcher-input">
                        <option value="legend">Legenda</option>
                        <option value="historical">Miejsce historyczne</option>
                        <option value="user">Dodane przez użytkownika</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Współrzędne:</label>
                    <p>${latLng.lat().toFixed(6)}, ${latLng.lng().toFixed(6)}</p>
                </div>
            </form>
        `;
        
        const modal = enhancedUI.createModal('add-legend', 'Dodaj Legendę', content, {
            footer: `
                <button class="witcher-btn" onclick="enhancedMap.saveLegend(${latLng.lat()}, ${latLng.lng()})">
                    <i class="material-icons">save</i>
                    Zapisz
                </button>
                <button class="witcher-btn secondary" onclick="enhancedUI.closeModal('add-legend')">
                    <i class="material-icons">cancel</i>
                    Anuluj
                </button>
            `
        });
        
        enhancedUI.openModal('add-legend');
    }

    showKMLUploadDialog() {
        const content = `
            <div class="kml-upload-dialog">
                <div class="witcher-dropzone" id="kml-dropzone">
                    <div class="dropzone-icon">📁</div>
                    <div class="dropzone-text">Przeciągnij plik KML tutaj</div>
                    <div class="dropzone-subtext">lub kliknij aby wybrać plik</div>
                    <input type="file" accept=".kml,.kmz" style="display: none;" id="kml-file-input">
                </div>
                <div class="kml-info">
                    <h4>Obsługiwane formaty:</h4>
                    <ul>
                        <li>KML (.kml)</li>
                        <li>KMZ (.kmz)</li>
                    </ul>
                </div>
            </div>
        `;
        
        const modal = enhancedUI.createModal('kml-upload', 'Wczytaj plik KML', content);
        enhancedUI.openModal('kml-upload');
        
        // Setup file upload
        const dropzone = document.getElementById('kml-dropzone');
        const fileInput = document.getElementById('kml-file-input');
        
        dropzone.addEventListener('click', () => fileInput.click());
        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length > 0) {
                this.loadKMLFile(e.target.files[0]);
                enhancedUI.closeModal('kml-upload');
            }
        });
        
        // Drag and drop
        dropzone.addEventListener('drop', (e) => {
            e.preventDefault();
            const files = Array.from(e.dataTransfer.files);
            const kmlFile = files.find(file => file.name.toLowerCase().endsWith('.kml') || file.name.toLowerCase().endsWith('.kmz'));
            
            if (kmlFile) {
                this.loadKMLFile(kmlFile);
                enhancedUI.closeModal('kml-upload');
            } else {
                this.showNotification('Proszę wybrać plik KML lub KMZ', 'warning');
            }
        });
    }

    saveLegend(lat, lng) {
        const title = document.getElementById('legend-title').value;
        const description = document.getElementById('legend-description').value;
        const type = document.getElementById('legend-type').value;
        
        if (!title.trim()) {
            this.showNotification('Proszę wprowadzić tytuł legendy', 'warning');
            return;
        }
        
        const legendData = {
            id: Date.now().toString(),
            title: title.trim(),
            description: description.trim(),
            type: type,
            position: { lat, lng },
            source: 'user',
            created: new Date().toISOString()
        };
        
        this.addLegendMarker(legendData);
        enhancedUI.closeModal('add-legend');
        this.showNotification('Legenda została dodana pomyślnie!', 'success');
        
        // Save to offline storage if available
        if (window.enhancedPWA) {
            enhancedPWA.submitLegend(legendData);
        }
    }

    // Sample legends for demonstration
    loadSampleLegends() {
        const sampleLegends = [
            {
                id: 'sample1',
                title: 'Legenda o Smoku Wawelskim',
                description: 'W jaskini pod Wawelem mieszkał straszny smok, który terroryzował mieszkańców Krakowa...',
                position: { lat: 50.0547, lng: 19.9350 },
                type: 'legend'
            },
            {
                id: 'sample2',
                title: 'Puszcza Białowieska - Królestwo Żubrów',
                description: 'Ostatnia pierwotna puszcza Europy, gdzie żyją żubry i duchy dawnych czasów...',
                position: { lat: 52.7000, lng: 23.8500 },
                type: 'historical'
            },
            {
                id: 'sample3',
                title: 'Morskie Oko - Oko Smoka',
                description: 'Najpiękniejsze jezioro Tatr, według legend powstałe z łzy smoka...',
                position: { lat: 49.2000, lng: 20.0700 },
                type: 'legend'
            }
        ];
        
        sampleLegends.forEach(legend => {
            setTimeout(() => {
                this.addLegendMarker(legend);
            }, Math.random() * 2000);
        });
    }

    // Utility methods
    toggleLegendPanel() {
        // Implementation for legend panel toggle
        this.showNotification('Panel legend - funkcja w rozwoju', 'info');
    }

    editLegend(id) {
        this.showNotification('Edycja legendy - funkcja w rozwoju', 'info');
    }

    shareLegend(id) {
        this.showNotification('Udostępnianie legendy - funkcja w rozwoju', 'info');
    }

    showNotification(message, type) {
        if (window.enhancedUI) {
            enhancedUI.showNotification(message, type);
        } else {
            console.log(`${type.toUpperCase()}: ${message}`);
        }
    }
}

// Initialize Enhanced Map
let enhancedMap;

// Wait for DOM and other modules to load
document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        enhancedMap = new EnhancedMap();
        window.enhancedMap = enhancedMap;
    }, 1000);
});

// Add CSS for map components
const mapStyle = document.createElement('style');
mapStyle.textContent = `
    .map-control {
        margin: 10px;
    }
    
    .legend-info-window {
        max-width: 300px;
    }
    
    .legend-info-window .legend-title {
        font-family: var(--font-primary);
        color: var(--witcher-gold);
        margin-bottom: 0.5rem;
        font-size: 1.1rem;
    }
    
    .legend-info-window .legend-description {
        margin-bottom: 1rem;
        line-height: 1.4;
    }
    
    .legend-info-window .legend-meta {
        display: flex;
        gap: 0.5rem;
        margin-bottom: 1rem;
        flex-wrap: wrap;
    }
    
    .legend-info-window .legend-type,
    .legend-info-window .legend-source {
        background: rgba(139, 69, 19, 0.3);
        color: var(--witcher-gold);
        padding: 0.2rem 0.5rem;
        border-radius: 10px;
        font-size: 0.8rem;
    }
    
    .legend-info-window .legend-actions {
        display: flex;
        gap: 0.5rem;
    }
    
    .legend-info-window .witcher-btn {
        padding: 0.4rem 0.8rem;
        font-size: 0.8rem;
    }
    
    .kml-upload-dialog .kml-info {
        margin-top: 1.5rem;
        padding-top: 1rem;
        border-top: 1px solid rgba(215, 203, 172, 0.3);
    }
    
    .kml-upload-dialog .kml-info h4 {
        font-family: var(--font-primary);
        color: var(--witcher-gold);
        margin-bottom: 0.5rem;
    }
    
    .kml-upload-dialog .kml-info ul {
        list-style: none;
        padding: 0;
    }
    
    .kml-upload-dialog .kml-info li {
        padding: 0.2rem 0;
        color: rgba(215, 203, 172, 0.8);
    }
    
    #map-container {
        width: 100%;
        height: 500px;
        border-radius: 8px;
        overflow: hidden;
        border: 1px solid rgba(215, 203, 172, 0.3);
    }
`;
document.head.appendChild(mapStyle);

