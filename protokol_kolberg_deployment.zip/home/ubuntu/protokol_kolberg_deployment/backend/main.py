from flask import Flask, send_from_directory, jsonify, request, render_template_string
from flask_cors import CORS
import os
import json
import time
import sqlite3
from datetime import datetime, timedelta
import threading
import queue
import uuid

app = Flask(__name__, static_folder='static', template_folder='templates')
app.config['SECRET_KEY'] = 'kolberg_2_0_protocol_secret_key_2025'

# Enable CORS for all routes
CORS(app, origins="*")

# Initialize database for offline queue and rate limiting
def init_db():
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    
    # Create tables
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS offline_queue (
            id TEXT PRIMARY KEY,
            type TEXT NOT NULL,
            data TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'pending',
            retry_count INTEGER DEFAULT 0
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS rate_limits (
            endpoint TEXT PRIMARY KEY,
            count INTEGER DEFAULT 0,
            window_start DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS legends (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT,
            location TEXT,
            tags TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS manuscripts (
            id TEXT PRIMARY KEY,
            filename TEXT NOT NULL,
            content TEXT,
            metadata TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

# Initialize database on startup
init_db()

# Rate limiting decorator
def rate_limit(endpoint, limit=10, window=300):  # 10 requests per 5 minutes
    def decorator(f):
        def wrapper(*args, **kwargs):
            conn = sqlite3.connect('protokol_kolberg.db')
            cursor = conn.cursor()
            
            now = datetime.now()
            window_start = now - timedelta(seconds=window)
            
            # Clean old entries
            cursor.execute('DELETE FROM rate_limits WHERE window_start < ?', (window_start,))
            
            # Check current count
            cursor.execute('SELECT count FROM rate_limits WHERE endpoint = ?', (endpoint,))
            result = cursor.fetchone()
            
            if result and result[0] >= limit:
                conn.close()
                return jsonify({'error': 'Rate limit exceeded', 'retry_after': window}), 429
            
            # Update count
            if result:
                cursor.execute('UPDATE rate_limits SET count = count + 1 WHERE endpoint = ?', (endpoint,))
            else:
                cursor.execute('INSERT INTO rate_limits (endpoint, count) VALUES (?, 1)', (endpoint,))
            
            conn.commit()
            conn.close()
            
            return f(*args, **kwargs)
        wrapper.__name__ = f.__name__
        return wrapper
    return decorator

@app.route('/')
def index():
    """Serve the main PWA application"""
    return send_from_directory(app.static_folder, 'index.html')

@app.route('/<path:path>')
def serve_static(path):
    """Serve static files with fallback to index.html for SPA routing"""
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')

@app.route('/api/status')
def status():
    """API status endpoint with system information"""
    return jsonify({
        'system': 'Protokół Kolberg 2.0',
        'version': '2.0.0',
        'status': 'active',
        'system_status': 'ai_pipeline:active',
        'modules': {
            'ASPID': 'Automated System for Processing and Indexing Data',
            'MKP2': 'Module for Communication Protocol Kolberg 2.0',
            'IMWDP': 'Interactive Module for Spatial Data Visualization'
        },
        'endpoints': {
            'ASPID': '/api/aspid/*',
            'MKP2': '/api/mkp2/*',
            'IMWDP': '/api/imwdp/*'
        },
        'features': {
            'offline_queue': True,
            'background_sync': True,
            'push_notifications': True,
            'rate_limiting': True,
            'ai_pipeline': True
        }
    })

@app.route('/api/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'uptime': time.time()
    })

# ASPID endpoints
@app.route('/api/aspid/upload', methods=['POST'])
@rate_limit('aspid_upload', limit=20, window=300)
def aspid_upload():
    """Handle file upload for OCR/transcription"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    # Generate unique ID
    manuscript_id = str(uuid.uuid4())
    
    # Simulate OCR processing
    manuscript_data = {
        'id': manuscript_id,
        'filename': file.filename,
        'content': f'Rozpoznany tekst z pliku {file.filename}...',
        'metadata': json.dumps({
            'confidence': 85,
            'language': 'polish',
            'type': 'slavic_legend',
            'processing_time': 2.5
        })
    }
    
    # Store in database
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO manuscripts (id, filename, content, metadata)
        VALUES (?, ?, ?, ?)
    ''', (manuscript_data['id'], manuscript_data['filename'], 
          manuscript_data['content'], manuscript_data['metadata']))
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'success',
        'message': 'File uploaded and processed successfully',
        'manuscript_id': manuscript_id,
        'filename': file.filename,
        'processing': 'OCR analysis completed',
        'confidence': 85
    })

@app.route('/api/aspid/upload-queued', methods=['POST'])
def aspid_upload_queued():
    """Handle queued file upload for offline support"""
    data = request.get_json()
    
    queue_id = str(uuid.uuid4())
    
    # Add to offline queue
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO offline_queue (id, type, data)
        VALUES (?, ?, ?)
    ''', (queue_id, 'manuscript_upload', json.dumps(data)))
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'queued',
        'queue_id': queue_id,
        'message': 'Upload queued for processing'
    })

@app.route('/api/aspid/manuscripts')
def aspid_manuscripts():
    """Get list of processed manuscripts"""
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM manuscripts ORDER BY timestamp DESC LIMIT 50')
    manuscripts = cursor.fetchall()
    conn.close()
    
    result = []
    for manuscript in manuscripts:
        result.append({
            'id': manuscript[0],
            'filename': manuscript[1],
            'content': manuscript[2][:200] + '...' if len(manuscript[2]) > 200 else manuscript[2],
            'metadata': json.loads(manuscript[3]) if manuscript[3] else {},
            'timestamp': manuscript[4]
        })
    
    return jsonify(result)

# MKP2 endpoints
@app.route('/api/mkp2/send', methods=['POST'])
@rate_limit('mkp2_send', limit=30, window=300)
def mkp2_send():
    """Handle communication protocol messages"""
    data = request.get_json()
    message = data.get('message', '') if data else ''
    
    # Simulate protocol processing
    responses = [
        f'Protokół Kolberg 2.0 otrzymał: {message}',
        f'Transmisja zakończona pomyślnie. Wiadomość: "{message}" została zarchiwizowana.',
        f'Sieć mistycznych przekaźników przetworzyła: {message}',
        f'Legenda została zapisana w kronikach. Treść: {message}'
    ]
    
    import random
    response = random.choice(responses)
    
    return jsonify({
        'status': 'success',
        'response': response,
        'timestamp': datetime.now().isoformat(),
        'protocol_version': '2.0',
        'message_id': str(uuid.uuid4())
    })

@app.route('/api/mkp2/messages')
def mkp2_messages():
    """Get recent protocol messages"""
    # Simulate message history
    messages = [
        {'id': '1', 'content': 'System inicjalizacji zakończony', 'timestamp': datetime.now().isoformat(), 'type': 'system'},
        {'id': '2', 'content': 'Połączenie z siecią mistycznych przekaźników nawiązane', 'timestamp': datetime.now().isoformat(), 'type': 'network'},
        {'id': '3', 'content': 'Protokół Kolberg 2.0 aktywny', 'timestamp': datetime.now().isoformat(), 'type': 'status'}
    ]
    
    return jsonify(messages)

# IMWDP endpoints
@app.route('/api/imwdp/add-legend', methods=['POST'])
@rate_limit('imwdp_legend', limit=30, window=300)
def imwdp_add_legend():
    """Add new legend to the map"""
    data = request.get_json()
    
    legend_id = str(uuid.uuid4())
    
    # Store legend in database
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO legends (id, title, content, location, tags)
        VALUES (?, ?, ?, ?, ?)
    ''', (legend_id, data.get('title', ''), data.get('content', ''),
          data.get('location', ''), json.dumps(data.get('tags', []))))
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'success',
        'legend_id': legend_id,
        'message': 'Legend added successfully',
        'title': data.get('title', ''),
        'location': data.get('location', '')
    })

@app.route('/api/imwdp/add-legend-queued', methods=['POST'])
def imwdp_add_legend_queued():
    """Add legend to offline queue"""
    data = request.get_json()
    
    queue_id = str(uuid.uuid4())
    
    # Add to offline queue
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO offline_queue (id, type, data)
        VALUES (?, ?, ?)
    ''', (queue_id, 'legend_add', json.dumps(data)))
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'queued',
        'queue_id': queue_id,
        'message': 'Legend queued for processing'
    })

@app.route('/api/imwdp/legends')
def imwdp_legends():
    """Get list of legends"""
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM legends ORDER BY timestamp DESC LIMIT 50')
    legends = cursor.fetchall()
    conn.close()
    
    result = []
    for legend in legends:
        result.append({
            'id': legend[0],
            'title': legend[1],
            'content': legend[2],
            'location': legend[3],
            'tags': json.loads(legend[4]) if legend[4] else [],
            'timestamp': legend[5]
        })
    
    return jsonify(result)

@app.route('/api/imwdp/locations')
def imwdp_locations():
    """Get map locations"""
    # Simulate location data
    locations = [
        {'id': '1', 'name': 'Puszcza Białowieska', 'lat': 52.7, 'lng': 23.8, 'type': 'forest'},
        {'id': '2', 'name': 'Góry Świętokrzyskie', 'lat': 50.9, 'lng': 20.7, 'type': 'mountains'},
        {'id': '3', 'name': 'Mazury', 'lat': 53.8, 'lng': 21.5, 'type': 'lakes'}
    ]
    
    return jsonify(locations)

# Queue management endpoints
@app.route('/api/queue/add', methods=['POST'])
def queue_add():
    """Add item to processing queue"""
    data = request.get_json()
    
    queue_id = str(uuid.uuid4())
    
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO offline_queue (id, type, data)
        VALUES (?, ?, ?)
    ''', (queue_id, data.get('type', 'generic'), json.dumps(data.get('data', {}))))
    conn.commit()
    conn.close()
    
    return jsonify({
        'status': 'success',
        'queue_id': queue_id,
        'message': 'Item added to queue'
    })

@app.route('/api/queue/status/<queue_id>')
def queue_status(queue_id):
    """Get queue item status"""
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM offline_queue WHERE id = ?', (queue_id,))
    item = cursor.fetchone()
    conn.close()
    
    if not item:
        return jsonify({'error': 'Queue item not found'}), 404
    
    return jsonify({
        'id': item[0],
        'type': item[1],
        'status': item[4],
        'retry_count': item[5],
        'timestamp': item[3]
    })

@app.route('/api/queue/stats')
def queue_stats():
    """Get queue statistics"""
    conn = sqlite3.connect('protokol_kolberg.db')
    cursor = conn.cursor()
    
    cursor.execute('SELECT status, COUNT(*) FROM offline_queue GROUP BY status')
    stats = dict(cursor.fetchall())
    
    cursor.execute('SELECT COUNT(*) FROM offline_queue')
    total = cursor.fetchone()[0]
    
    conn.close()
    
    return jsonify({
        'total': total,
        'pending': stats.get('pending', 0),
        'completed': stats.get('completed', 0),
        'failed': stats.get('failed', 0)
    })

# AI Pipeline endpoints (simulated)
@app.route('/api/ai/enhance-text', methods=['POST'])
@rate_limit('ai_enhance', limit=10, window=300)
def ai_enhance_text():
    """Enhance OCR text using AI"""
    data = request.get_json()
    text = data.get('text', '')
    
    # Simulate AI enhancement
    enhanced_text = f"[AI Enhanced] {text}"
    
    return jsonify({
        'status': 'success',
        'original_text': text,
        'enhanced_text': enhanced_text,
        'confidence': 92,
        'improvements': ['spelling_correction', 'grammar_enhancement', 'cultural_context']
    })

@app.route('/api/ai/classify-legend', methods=['POST'])
@rate_limit('ai_classify', limit=10, window=300)
def ai_classify_legend():
    """Classify legend using AI"""
    data = request.get_json()
    text = data.get('text', '')
    
    # Simulate AI classification
    categories = ['folklor', 'słowiańskie', 'duchy_lasu', 'mitologia']
    
    return jsonify({
        'status': 'success',
        'text': text,
        'categories': categories,
        'confidence': 88,
        'cultural_context': 'Słowiańska mitologia leśna'
    })

@app.route('/api/ai/pipeline-status')
def ai_pipeline_status():
    """Get AI pipeline status"""
    return jsonify({
        'status': 'active',
        'services': {
            'gemini_pro': {'status': 'active', 'rate_limit': '10/5min'},
            'perplexity': {'status': 'active', 'rate_limit': '5/5min'},
            'ocr_enhancement': {'status': 'active', 'rate_limit': '20/5min'}
        },
        'queue_size': 0,
        'processing': False
    })

if __name__ == '__main__':
    print("=" * 60)
    print("🏰 Protokół Kolberg 2.0 - Enhanced PWA Implementation")
    print("=" * 60)
    print("ASPID:  Automated System for Processing and Indexing Data")
    print("MKP2:   Module for Communication Protocol Kolberg 2.0")
    print("IMWDP:  Interactive Module for Spatial Data Visualization")
    print("=" * 60)
    print("Features:")
    print("✅ Offline Queue Management")
    print("✅ Rate Limiting")
    print("✅ Background Sync")
    print("✅ AI Pipeline Integration")
    print("✅ SQLite Database")
    print("✅ PWA Support")
    print("=" * 60)
    print(f"Static folder: {app.static_folder}")
    print("Server starting on http://0.0.0.0:5000")
    print("API Documentation available at /api/status")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5000, debug=True)

